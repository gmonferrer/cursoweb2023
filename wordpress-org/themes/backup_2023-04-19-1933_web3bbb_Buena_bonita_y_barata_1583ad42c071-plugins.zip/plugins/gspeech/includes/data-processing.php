<?php

// no direct access!
defined('ABSPATH') or die("No direct access");

/******************************
* data processing
******************************/

// this function saves the data
function wpgs_save_data() {
	// save data here
}