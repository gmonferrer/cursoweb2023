<?php
$GLOBALS['jvcf7_current_version']				= '5.3';

$GLOBALS['jvcf7_default_settings'] 				= array(
		'jvcf7_show_label_error'				=> "errorMsgshow",
		'jvcf7_invalid_field_design'			=> "theme_0"
		);