/**
 * Internal dependencies
 */
import './block-editor/index.js';
