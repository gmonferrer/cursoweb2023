<?php if ( class_exists( 'FLBuilderModel' ) && FLBuilderModel::is_builder_active() ) : ?>
  <div id="ti-tpc-beaver"></div>
	<?php
endif;
