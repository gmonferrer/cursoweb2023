### How to translate Cloud Templates & Patterns collection?

You can help translate Cloud Templates & Patterns collection by using the [WordPress.org](https://translate.wordpress.org/projects/wp-plugins/templates-patterns-collection/) translation page.

### How to generate the translation file?

You can run the following commands to build the translation file:
* `yarn install --frozen-lockfile`
* `yarn run build:makepot`
